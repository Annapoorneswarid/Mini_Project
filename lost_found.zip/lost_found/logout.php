<?php
session_start();
include("../connection.php");
header("location:index.php");
session_destroy()
?>