<?php
if(isset($_POST['submit']))
{
include("connection.php");
$category=$_POST['cata'];
$pincode=$_POST['pincode'];
$des=$_POST['discription'];
$city=$_POST['city'];
$street=$_POST['street'];
$ph=$_POST['phone'];
$date=$_POST['date'];

$fileName=$_FILES["limage"]["name"];
$targetDir="Item/";
$targetFilePath = $targetDir . $fileName; 
move_uploaded_file($_FILES["limage"]["tmp_name"], $targetFilePath);

$a=mysqli_query($con,"INSERT INTO `lost` (`item`,`type`, `pincode`, `description`, `city`, `street`, `date`, `image`) 
   VALUES ('$category','found','$pincode','$des','$city','$street','$date','$fileName')");
   
   header("Location:items.php");
}

?>



