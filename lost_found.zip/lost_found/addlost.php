<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Lost And Found</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Humberger Begin -->
    <div class="humberger__menu__overlay"></div>
    <div class="humberger__menu__wrapper">
        <div class="humberger__menu__logo">
            <a href="#"><img src="img/logo2.jpg" alt=""></a>
        </div>
        <div class="humberger__menu__cart">
           
        </div>
        <div class="humberger__menu__widget">
            <div class="header__top__right__language">
                <img src="img/language.png" alt="">
                <div>English</div>
                <span class="arrow_carrot-down"></span>
                <ul>
                    
                    <li><a href="#">English</a></li>
                </ul>
            </div>
            <div class="header__top__right__auth">
                <a href="logout.php"><i class="fa fa-user"></i>Logout </a>
                
            </div>
        </div>
        <nav class="humberger__menu__nav mobile-menu">
            <ul>
                <li class="active"><a href="./login.html">Home</a></li>
                
                
    
                
                <li><a href="./contact.html">Contact</a></li>
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="header__top__right__social">
             
        </div>
        <div class="humberger__menu__contact">
            <ul>
               
            </ul>
        </div>
    </div>
    <!-- Humberger End -->

    <!-- Header Section Begin -->
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="header__top__left">
                            
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="header__top__right">
                            <div class="header__top__right__social">
                               
                            </div>
                            <div class="header__top__right__language">
                                <img src="img/language.png" alt="">
                                <div>English</div>
                                <span class="arrow_carrot-down"></span>
                                <ul>
                                    
                                    <li><a href="#">English</a></li>
                                </ul>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="header__logo">
                        <a href="./index.html"><img src="img/logo2.jpg" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="header__menu">
                        <ul>
                            <li class="active"><a href="./login.html">Home</a></li>
                            
                            <li class="active"><a href="logout.php">Logout</a></li>
                
                
               
                           
                    </nav>
                </div>
                <div class="col-lg-3">
                    <div class="header__cart">
                       
                    </div>
                </div>
            </div>
            <div class="humberger__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header Section End -->

    
    
<!-- User Profile -->

<nav class="  blue-grey darken-3 z-depth-2">
    <div class="nav-wrapper  ">

        <!--<a href="#" class="brand-logo " style="margin-left: 20px;text-transform: uppercase;">Lost And Found</a>-->
        <ul class="right hide-on-med-and-down">

            <!--<li><a href="about.php">About</a></li>-->
            
<div class="container" style="margin-left: 380px;">
    <div class="row">
        <div class="col s6">
            <div class="">
                <div class=" ">
                    <div class="card-panel blue-grey darken-4 z-depth-5">
          <span class="white-text flow-text"><b>ENTER DETAIL ABOUT LOST ITEM</b>
          </span>
          <form class="" method="POST" enctype="multipart/form-data">
            <div class="col s8">
                <div class="col s6">
                    <div class="input-field col s10 white-text">
                        <i class="material-icons prefix " style="margin-top: 10px;" >
                        </i>
                        <select name="cata" required>
                            <option value=""  class="" value="0">Select Category</option>
                            <option value="watch"  class="" value="0">Watch</option>
                            <option value="wallet"  class="" value="0">Wallet</option>
                            <option value="idproof"  class="" value="0">Id Proofs</option>
                            <option value="bags"  class="" value="0">Bags</option>
                            <option value="electronicitems"  class="" value="0">Electronic items</option>
                            <option value="ornaments"  class="" value="0">Ornaments</option>
                            <option value="others"  class="" value="0">Others</option>
                           
                        </select>
                        <br> <br>
                    </div>
                </div>
                <div class="col s6">
                    <div class="input-field col s10">
                        <i class="material-icons prefix"></i>
                        <label for="icon_prefix " class="white-text">Pincode</label>
                        <input id="icon_prefix" type="number" required class="validate" name="pincode" minlength="5" maxlength="6">
                       
                    </div>

                </div>
                <br>
                <div class="col s6">
                    <div class="input-field col s10">
                        <i class="material-icons prefix"></i>
                        <label for="icon_prefix2 " class="white-text">Description</label>
                        <textarea id="icon_prefix2" required class="materialize-textarea" name="discription" minlength="10" maxlength="80"></textarea>
                        
                    </div>
                </div>
                <br>

                <div class="col s6">
                    <div class="input-field col s10">
                        <i class="material-icons prefix"></i>
                        <label for="city" class="white-text">City/State</label>
                        <input id="city" type="text" required class="validate" name="city" minlength="4">
                        
                    </div>

                </div>
                <br>


                <div class="col s6">
                    <div class="input-field col s10">
                        <i class="material-icons prefix"></i>
                        <label for="locality" class="white-text">Sreet/Locality</label>
                        <input id="locality" type="text" required class="validate" name="street" minlength="4">
                       
                    </div>

                </div>
                <br>



                <div class="col s6">
                    <div class="input-field col s10">
                        <i class="material-icons prefix"></i>
                        <label for="phone" class="white-text">Phone</label>
                        <input id="phone" type="number" required class="validate" name="phone" maxlength="10" minlength="10">
                        
                    </div>

                </div>
                <br>


                <div class="col s6">
                    <div class="input-field col s10">
                        <i class="material-icons prefix">Date</i>
                        <input  class="materialize-textarea" required type="date" name="date"></input>

                    </div>
                </div>

                <br>
            </div>

            <div class="col s4 imagesubmit">
                <div class="col 12">

                        <input type="file" name="limage" id="input-file-now-custom-1" class="dropify" data-height="250"
                               data-max-file-size="1M" >
                    </div>
                </div>
            </div>
            <br>
            <div class="col s6 " style="margin-left: 20px; margin-bottom: 10px ;border-radius: 100px;">
                
               
                <button type="submit"  value="submit" name="submit" class="site-btn">Submit</button>
                    
            
            </div>
    </div>
    </form>
                        <br>
                        <br>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<BR>
    <BR>

    
</nav>
    
   
        <div class="row">
            <div class="col-lg-12">
                <div class="footer__copyright">
                    <div class="footer__copyright__text"><p>
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved    by <a href="https://colorlib.com" target="_blank">Annapoorneswari D</a><i class="fa fa-heart" aria-hidden="true"></i>
</p></div>
                    
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>


</body>

</html>

<?php

include("connection.php");
if(isset($_POST['submit']))
{
$category=$_POST['cata'];
$pincode=$_POST['pincode'];
$des=$_POST['discription'];
$city=$_POST['city'];
$street=$_POST['street'];
$ph=$_POST['phone'];
$date=$_POST['date'];

$fileName=$_FILES["limage"]["name"];
$targetDir="Item/";
$targetFilePath = $targetDir . $fileName; 
move_uploaded_file($_FILES["limage"]["tmp_name"], $targetFilePath);

$a=mysqli_query($con,"INSERT INTO `lost` (`item`,`type`, `pincode`, `description`, `city`, `street`, `date`, `image`) 
   VALUES ('$category','lost','$pincode','$des','$city','$street','$date','$fileName')");
   
   echo "<script>location='items.php';</script>";
}

?>



