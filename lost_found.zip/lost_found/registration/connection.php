<?php
$con = mysqli_connect('localhost','root','','lost_and_found');

?>