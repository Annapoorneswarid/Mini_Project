<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up Form </title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
    <script>
    function registration()
            {
              var name= document.getElementById("name").value;
              var email= document.getElementById("email").value;
              var phone= document.getElementById("phone").value;
              var address= document.getElementById("address").value;
              var id=document.getElementById("id").value;
              var Password= document.getElementById("pass").value;
              var CPassword= document.getElementById("cnfpass").value;
              
              //email id expression code
              var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
              var letters = /^[A-Za-z]+$/;
              var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
              var phoneno = /^\d{10}$/;
              
          if(name=='')
              {
                alert('Please enter your name');
                return false;
              }
              
              if(email=='')
              {
                alert('Please enter your email');
                return false;
              }
              
             
          if(phone=='')  
              {
                alert('Please enter your phone number');
                return false;
              }
          if(!phoneno.test(phone))
              {
                alert('Enter your phone number correctly');
                return false;
              }
          
              
              if(Password=='')
              {
                alert('Please enter Password');
                return false;
              }
              if(CPassword=='')
              {
                alert('Enter Confirm Password');
                return false;
              }
              if(!pwd_expression.test(Password))
              {
                alert ('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
                return false;
              }
              if(Password != CPassword )
              {
                alert ('Password not Matched');
                return false;
              }
              if(document.getElementById("Password").value.length < 6)
              {
                alert ('Password minimum length is 6');
                return false;
              }
              if(document.getElementById("CPassword").value.length > 12)
              {
                alert ('Password max length is 12');
                return false;
              }
              else
              {                            
                  alert('Successfully Registered');
                return true;
                
              }
            }
            </script>
</head>
<body>

    <div class="main">

        <h1>Sign up</h1>
        <div class="container">
            <div class="sign-up-content">
                <form method="POST" class="signup-form" onsubmit="return registration();">
                    <h2 class="form-title">Register New Account</h2>
                   <!-- <div class="form-radio">
                        <input type="radio" name="member_level" value="newbie" id="newbie" checked="checked" />
                        <label for="newbie">user</label>

                        <input type="radio" name="member_level" value="average" id="average" />
                        <label for="average"></label>

                        <input type="radio" name="member_level" value="master" id="master" />
                        <label for="master">Master</label>
                    </div>-->

                    <div class="form-textbox">
                        <label for="name">Full name</label>
                        <input type="text" name="name" id="name"  />
                        
                    </div>
                    <div class="form-textbox">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" />
                    </div>
                    <div class="form-textbox">
                        <label for="Phone No.">Phone No.</label>
                        <input type="number" name="phone" id="phone" />
                    </div>
                    <div class="form-textbox">
                        <label for="Address">Address</label>
                        <input type="text" name="address" id="address" />
                    </div>

                    <div class="form-textbox">
                        <label for="idproof">Id Proof No.</label>
                        <select id="idproof" name="idproof">
      <option value="aadhar">Aadhaar Card</option>
      <option value="license">License</option>
      <option value="pancard">Pancard</option>
    </select>
                        
                        <input type="text" name="id" id="id" />
                    </div>

                    <div class="form-textbox">
                        <label for="pass">Password</label>
                        <input type="password" name="pass" id="pass" />
                    </div>
                    <div class="form-textbox">
                        <label for="pass">Confirm Password</label>
                        <input type="password" name="cnfpass" id="cnfpass" />
                    </div>

                    <div class="form-group">
                        <input type="checkbox" name="agree-term" id="agree-term" class="agree-term" />
                        <label for="agree-term" class="label-agree-term"><span><span></span></span>I agree all statements in  <a href="#" class="term-service">Terms of service</a></label>
                    </div>

                    <div class="form-textbox">
                        <input type="submit" name="submit" class="submit" value="Create account" />
                    </div>
                </form>

                <p class="loginhere">
                    Already have an account ?<a href="index1.php" class="loginhere-link"> Log in</a>
                </p>
            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
<?php
//Including database
include ("connection.php");
//Setting on the button click
if (isset($_POST['submit'])) {
//Getting all data from the form and inserting to variables
$name = $_POST['name'];
$email = $_POST['email'];
$number = $_POST['phone'];
$address = $_POST['address'];
$idproof = $_POST['id'];
$password = $_POST['pass'];
//Inserting to the login table
mysqli_query($con, "INSERT INTO `registration`( `Name`, `Email`,`Phone No`, `Address`, `Id Proof`) VALUES ('$name', '$email', '$number','$address' , '$idproof')");

//Accruing login_id from login table as to keep foriegn key
$r = mysqli_insert_id($con);
//Inserting to the registration table with login_id
mysqli_query($con, "INSERT INTO `login`(`Email`, `Passward`,`role_id`, `status`, `r_id`) VALUES ('$email','$password',1,1,'$r')");
//Moving to last page by showing Alert
echo '<script>
window.location.href = "http://localhost/lost_found/registration/index1.php";
</script>';
}
?>

