<?php
include("../connection.php");
header("location:../index.php");
?>